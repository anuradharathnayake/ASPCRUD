﻿using Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using WebApplication1.ServiceReference1;

namespace WebApplication1
{
    public partial class Contact : Page
    {
        public List<Employee> EmployeeList
        {
            get { return ViewState["CurrentPage"] as List<Employee>; }
            set { ViewState["CurrentPage"] = value; }
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            if (!Page.IsPostBack)
            {
                EmployeeDataAccessLayer employee = new EmployeeDataAccessLayer();
                EmployeeList = employee.GetAllEmployees();
                GridViewEmployee.DataSource = EmployeeList;
                GridViewEmployee.DataBind();
            }
        }

        protected void ButtonSearch_Click(object sender, EventArgs e)
        {
            var result = EmployeeList.FindAll(item => item.City == TextBoxCity.Text || item.Name == TextBoxName.Text).ToList();
            GridViewEmployee.DataSource = result;
            GridViewEmployee.DataBind();
        }

        protected void Clear_Click(object sender, EventArgs e)
        {
            GridViewEmployee.DataSource = EmployeeList;
            GridViewEmployee.DataBind();

           
        }

        protected void GridViewEmployee_RowEditing(object sender, GridViewEditEventArgs e)
        {
           

        }

        protected void GridViewEmployee_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {

        }

        protected void GridViewEmployee_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {

        }

        protected void Button2_Click(object sender, EventArgs e)
        {
             try
            {
                GeocoderService_V04_01SoapClient client = new GeocoderService_V04_01SoapClient();
                WebApplication1.ServiceReference1.WebServiceGeocodeQueryResultSet temp = client.GeocodeAddressNonParsed(
                    "3620 North Vermont Ave W.",
    "Beverly Hills",
    "CA",
    "90089",
    "api - key - value",
    4.01,
    true,
    ServiceReference1.CensusYear.TwoThousand,
    true,
    true);
            }
            catch(Exception ex)
            {

            }
        }
    }
}